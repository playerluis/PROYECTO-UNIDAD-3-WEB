package com.espe.pry.controllers;

import com.espe.pry.idao.UsuarioDaoImpl;
import com.espe.pry.models.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.SneakyThrows;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "usuarioServlet", value = "/usuario")
public class UsuarioServlet extends HttpServlet {
    private final UsuarioDaoImpl dao;

    public UsuarioServlet() {
        dao = new UsuarioDaoImpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String opcion = req.getParameter("opcion");
        if (opcion == null)
            opcion = "index";

        switch (opcion) {
            case "registro": {
                req.getRequestDispatcher("entidades/usuario/create.jsp").forward(req, resp);
                break;
            }
            case "eliminar": {
                Usuario model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("usuario", model);
                req.getRequestDispatcher("entidades/usuario/delete.jsp").forward(req, resp);
                break;
            }
            case "editar": {
                Usuario model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("usuario", model);
                req.getRequestDispatcher("entidades/usuario/edit.jsp").forward(req, resp);
                break;
            }
            case "detalles": {
                Usuario model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("usuario", model);
                req.getRequestDispatcher("entidades/usuario/details.jsp").forward(req, resp);
                break;
            }
            default: {
                List<Usuario> lista = dao.findAll();
                req.setAttribute("usuarios", lista);
                req.getRequestDispatcher("entidades/usuario/index.jsp").forward(req, resp);
                break;
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Usuario model = dao.parse(req);
        dao.save(model);
        resp.sendRedirect("/entidades/usuario/index.jsp");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Usuario model = dao.parse(req);
        dao.edit(model);
        req.getRequestDispatcher("entidades/usuario/index.jsp").forward(req, resp);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Usuario model = dao.find(Long.parseLong(req.getParameter("id")));
        dao.delete(model);
        req.getRequestDispatcher("entidades/usuario/index.jsp").forward(req, resp);
    }

}
