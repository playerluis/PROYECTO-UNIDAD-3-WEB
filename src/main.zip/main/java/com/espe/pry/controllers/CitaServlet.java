package com.espe.pry.controllers;

import com.espe.pry.idao.CitaDaoImpl;
import com.espe.pry.models.Cita;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "citaServlet", value = "/cita")
public class CitaServlet extends HttpServlet {
    private final CitaDaoImpl dao;

    public CitaServlet() {
        super();
        dao = new CitaDaoImpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String opcion = req.getParameter("opcion");
        if (opcion == null)
            opcion = "index";

        switch (opcion) {
            case "registro": {
                req.getRequestDispatcher("entidades/cita/create.jsp").forward(req, resp);
                break;
            }
            case "eliminar": {
                Cita model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("cita", model);
                req.getRequestDispatcher("entidades/cita/delete.jsp").forward(req, resp);
                break;
            }
            case "editar": {
                Cita model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("cita", model);
                req.getRequestDispatcher("entidades/cita/edit.jsp").forward(req, resp);
                break;
            }
            case "detalles": {
                Cita model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("cita", model);
                req.getRequestDispatcher("entidades/cita/details.jsp").forward(req, resp);
                break;
            }
            default: {
                List<Cita> lista = dao.findAll();
                req.setAttribute("citas", lista);
                req.getRequestDispatcher("entidades/cita/index.jsp").forward(req, resp);
                break;
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Cita model = dao.parse(req);
        dao.save(model);
        resp.sendRedirect("entidades/cita/index.jsp");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Cita model = dao.parse(req);
        dao.edit(model);
        req.getRequestDispatcher("entidades/cita/index.jsp").forward(req, resp);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Cita model = dao.find(Long.parseLong(req.getParameter("id")));
        dao.delete(model);
        req.getRequestDispatcher("entidades/cita/index.jsp").forward(req, resp);
    }

}