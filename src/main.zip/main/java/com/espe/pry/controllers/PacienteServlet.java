package com.espe.pry.controllers;

import com.espe.pry.idao.PacienteDaoImpl;
import com.espe.pry.models.Paciente;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "pacienteServlet", value = "/paciente")
public class PacienteServlet extends HttpServlet {
    private final PacienteDaoImpl dao;

    public PacienteServlet() {
        dao = new PacienteDaoImpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String opcion = req.getParameter("opcion");
        if (opcion == null)
            opcion = "index";

        switch (opcion) {
            case "registro": {
                req.getRequestDispatcher("entidades/paciente/create.jsp").forward(req, resp);
                break;
            }
            case "eliminar": {
                Paciente model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("usuario", model);
                req.getRequestDispatcher("entidades/paciente/delete.jsp").forward(req, resp);
                break;
            }
            case "editar": {
                Paciente model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("usuario", model);
                req.getRequestDispatcher("entidades/paciente/edit.jsp").forward(req, resp);
                break;
            }
            case "detalles": {
                Paciente model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("usuario", model);
                req.getRequestDispatcher("entidades/paciente/details.jsp").forward(req, resp);
                break;
            }
            default: {
                List<Paciente> lista = dao.findAll();
                req.setAttribute("usuarios", lista);
                req.getRequestDispatcher("entidades/paciente/index.jsp").forward(req, resp);
                break;
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Paciente model = dao.parse(req);
        dao.save(model);
        resp.sendRedirect("/entidades/paciente/index.jsp");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Paciente model = dao.parse(req);
        dao.edit(model);
        req.getRequestDispatcher("entidades/paciente/index.jsp").forward(req, resp);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Paciente model = dao.find(Long.parseLong(req.getParameter("id")));
        dao.delete(model);
        req.getRequestDispatcher("entidades/paciente/index.jsp").forward(req, resp);
    }
}