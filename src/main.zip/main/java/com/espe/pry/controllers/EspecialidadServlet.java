package com.espe.pry.controllers;

import com.espe.pry.idao.EspecialidadDaoImpl;
import com.espe.pry.idao.PacienteDaoImpl;
import com.espe.pry.models.Especialidad;
import com.espe.pry.models.Paciente;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "especialidadServlet", value = "/especialidad")
public class EspecialidadServlet extends HttpServlet {
    private final EspecialidadDaoImpl dao;

    public EspecialidadServlet() {
        dao = new EspecialidadDaoImpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String opcion = req.getParameter("opcion");
        if (opcion == null)
            opcion = "index";

        switch (opcion) {
            case "registro": {
                req.getRequestDispatcher("entidades/especialidad/create.jsp").forward(req, resp);
                break;
            }
            case "eliminar": {
                Especialidad model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("usuario", model);
                req.getRequestDispatcher("entidades/especialidad/delete.jsp").forward(req, resp);
                break;
            }
            case "editar": {
                Especialidad model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("usuario", model);
                req.getRequestDispatcher("entidades/especialidad/edit.jsp").forward(req, resp);
                break;
            }
            case "detalles": {
                Especialidad model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("usuario", model);
                req.getRequestDispatcher("entidades/especialidad/details.jsp").forward(req, resp);
                break;
            }
            default: {
                List<Especialidad> lista = dao.findAll();
                req.setAttribute("usuarios", lista);
                req.getRequestDispatcher("entidades/especialidad/index.jsp").forward(req, resp);
                break;
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Especialidad model = dao.parse(req);
        dao.save(model);
        resp.sendRedirect("/entidades/especialidad/index.jsp");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Especialidad model = dao.parse(req);
        dao.edit(model);
        req.getRequestDispatcher("entidades/especialidad/index.jsp").forward(req, resp);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Especialidad model = dao.find(Long.parseLong(req.getParameter("id")));
        dao.delete(model);
        req.getRequestDispatcher("entidades/especialidad/index.jsp").forward(req, resp);
    }
}