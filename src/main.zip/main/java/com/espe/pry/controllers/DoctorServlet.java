package com.espe.pry.controllers;

import com.espe.pry.idao.DoctorDaoImpl;
import com.espe.pry.models.Doctor;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "doctorServlet", value = "/doctor")
public class DoctorServlet extends HttpServlet {
    private final DoctorDaoImpl dao;

    public DoctorServlet() {
        super();
        dao = new DoctorDaoImpl();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String opcion = req.getParameter("opcion");
        if (opcion == null)
            opcion = "index";

        switch (opcion) {
            case "registro": {
                req.getRequestDispatcher("entidades/doctor/create.jsp").forward(req, resp);
                break;
            }
            case "eliminar": {
                Doctor model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("usuario", model);
                req.getRequestDispatcher("entidades/doctor/delete.jsp").forward(req, resp);
                break;
            }
            case "editar": {
                Doctor model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("usuario", model);
                req.getRequestDispatcher("entidades/doctor/edit.jsp").forward(req, resp);
                break;
            }
            case "detalles": {
                Doctor model = dao.find(Long.parseLong(req.getParameter("id")));
                req.setAttribute("usuario", model);
                req.getRequestDispatcher("entidades/doctor/details.jsp").forward(req, resp);
                break;
            }
            default: {
                List<Doctor> lista = dao.findAll();
                req.setAttribute("usuarios", lista);
                req.getRequestDispatcher("entidades/doctor/index.jsp").forward(req, resp);
                break;
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Doctor model = dao.parse(req);
        dao.save(model);
        resp.sendRedirect("entidades/doctor/index.jsp");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Doctor model = dao.parse(req);
        dao.edit(model);
        req.getRequestDispatcher("entidades/doctor/index.jsp").forward(req, resp);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Doctor model = dao.find(Long.parseLong(req.getParameter("id")));
        dao.delete(model);
        req.getRequestDispatcher("entidades/doctor/index.jsp").forward(req, resp);
    }

}