package com.espe.pry.dao;

import jakarta.servlet.http.HttpServletRequest;

import java.util.List;

public interface IDAO<Model> {
    void save(Model cita);

    void edit(Model cita);

    void delete(Model cita);

    Model find(Long id);

    List<Model> findAll();

    Model parse(HttpServletRequest request);

}
