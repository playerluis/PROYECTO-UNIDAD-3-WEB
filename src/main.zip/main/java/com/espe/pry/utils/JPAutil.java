package com.espe.pry.utils;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class JPAutil {
    private static EntityManager manager;
    private static EntityManagerFactory factory;
    private static final String PERSISTENCE_UNIT_NAME = "PERSISTENCE";

    public static EntityManager getEntityManager() {
        if (manager == null) {
            factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
            manager = factory.createEntityManager();
        }
        return manager;
    }

    public static void Shutdown() {
        if (manager != null)
            manager.close();

        if (factory != null)
            factory.close();

    }

}
