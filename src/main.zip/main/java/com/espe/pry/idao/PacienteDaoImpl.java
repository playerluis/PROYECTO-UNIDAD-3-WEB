package com.espe.pry.idao;

import com.espe.pry.dao.IDAO;
import com.espe.pry.models.Paciente;
import com.espe.pry.utils.JPAutil;
import jakarta.persistence.EntityManager;
import jakarta.servlet.http.HttpServletRequest;

import java.time.LocalDate;
import java.util.List;

public class PacienteDaoImpl implements IDAO<Paciente> {

    protected final EntityManager manager;

    public PacienteDaoImpl() {
        manager = JPAutil.getEntityManager();
    }


    public void save(Paciente model) {
        manager.getTransaction().begin();
        manager.persist(model); //linea del error
        manager.getTransaction().commit();
    }

    public void edit(Paciente model) {
        manager.getTransaction().begin();
        manager.merge(model);
        manager.getTransaction().commit();
    }

    public void delete(Paciente model) {
        manager.getTransaction().begin();
        manager.remove(model);
        manager.getTransaction().commit();
    }

    public Paciente find(Long id) {
        return manager.find(Paciente.class, id);
    }

    public List<Paciente> findAll() {
        return manager.createQuery("FROM Paciente", Paciente.class).getResultList();
    }

    @Override
    public Paciente parse(HttpServletRequest request) {
        Paciente paciente = new Paciente();

        paciente.setNombre(request.getParameter("nombre"));
        paciente.setApellido(request.getParameter("apellido"));
        paciente.setFechaDeNacimiento(LocalDate.parse(request.getParameter("fechaDeNacimiento")));
        paciente.setDireccion(request.getParameter("direccion"));

        return paciente;

    }
}