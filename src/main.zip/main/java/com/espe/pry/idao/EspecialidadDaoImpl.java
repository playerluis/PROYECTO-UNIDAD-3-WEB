package com.espe.pry.idao;

import com.espe.pry.dao.IDAO;
import com.espe.pry.models.Especialidad;
import com.espe.pry.utils.JPAutil;
import jakarta.persistence.EntityManager;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;

public class EspecialidadDaoImpl implements IDAO<Especialidad> {

    protected final EntityManager manager;

    public EspecialidadDaoImpl() {
        manager = JPAutil.getEntityManager();
    }


    public void save(Especialidad model) {
        manager.getTransaction().begin();
        manager.persist(model); //linea del error
        manager.getTransaction().commit();
    }

    public void edit(Especialidad model) {
        manager.getTransaction().begin();
        manager.merge(model);
        manager.getTransaction().commit();
    }

    public void delete(Especialidad model) {
        manager.getTransaction().begin();
        manager.remove(model);
        manager.getTransaction().commit();
    }

    public Especialidad find(Long id) {
        return manager.find(Especialidad.class, id);
    }

    public List<Especialidad> findAll() {
        return manager.createQuery("FROM Especialidad", Especialidad.class).getResultList();
    }

    @Override
    public Especialidad parse(HttpServletRequest request) {
        Especialidad especialidad = new Especialidad();

        especialidad.setNombre(request.getParameter("nombre"));

        return especialidad;

    }
}