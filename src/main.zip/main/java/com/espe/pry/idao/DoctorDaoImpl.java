package com.espe.pry.idao;

import com.espe.pry.dao.IDAO;
import com.espe.pry.models.Doctor;
import com.espe.pry.models.Especialidad;
import com.espe.pry.utils.JPAutil;
import jakarta.persistence.EntityManager;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;

public class DoctorDaoImpl implements IDAO<Doctor> {

    protected final EntityManager manager;

    public DoctorDaoImpl() {
        manager = JPAutil.getEntityManager();
    }


    public void save(Doctor model) {
        manager.getTransaction().begin();
        manager.persist(model); //linea del error
        manager.getTransaction().commit();
    }

    public void edit(Doctor model) {
        manager.getTransaction().begin();
        manager.merge(model);
        manager.getTransaction().commit();
    }

    public void delete(Doctor model) {
        manager.getTransaction().begin();
        manager.remove(model);
        manager.getTransaction().commit();
    }

    public Doctor find(Long id) {
        return manager.find(Doctor.class, id);
    }

    public List<Doctor> findAll() {
        return manager.createQuery("FROM Doctor", Doctor.class).getResultList();
    }

    @Override
    public Doctor parse(HttpServletRequest request) {
        Doctor doctor = new Doctor();
        Especialidad especialidad = manager.find(Especialidad.class, Integer.parseInt(request.getParameter("especialidad")));

        doctor.setNombre(request.getParameter("nombre"));
        doctor.setApellido(request.getParameter("apellido"));
        doctor.setEspecialidad(especialidad);
        doctor.setCedula(request.getParameter("cedula"));

        return doctor;
    }
}