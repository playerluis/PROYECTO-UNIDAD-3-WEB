package com.espe.pry.idao;

import com.espe.pry.dao.IDAO;
import com.espe.pry.models.Cita;
import com.espe.pry.models.Doctor;
import com.espe.pry.models.Paciente;
import com.espe.pry.utils.JPAutil;
import jakarta.persistence.EntityManager;
import jakarta.servlet.http.HttpServletRequest;

import java.time.LocalDateTime;
import java.util.List;


public class CitaDaoImpl implements IDAO<Cita> {

    protected final EntityManager manager;

    public CitaDaoImpl() {
        manager = JPAutil.getEntityManager();
    }

    public void save(Cita model) {
        manager.getTransaction().begin();
        manager.persist(model); //linea del error
        manager.getTransaction().commit();
    }

    public void edit(Cita model) {
        manager.getTransaction().begin();
        manager.merge(model);
        manager.getTransaction().commit();
    }

    public void delete(Cita model) {
        manager.getTransaction().begin();
        manager.remove(model);
        manager.getTransaction().commit();
    }

    public Cita find(Long id) {
        return manager.find(Cita.class, id);
    }

    public List<Cita> findAll() {
        return manager.createQuery("FROM Cita", Cita.class).getResultList();
    }

    @Override
    public Cita parse(HttpServletRequest request) {
        Cita cita = new Cita();

        Long pacienteId = Long.parseLong(request.getParameter("pacienteId"));
        Long doctorId = Long.parseLong(request.getParameter("doctorId"));

        Paciente paciente = manager.find(Paciente.class, pacienteId);
        Doctor doctor = manager.find(Doctor.class, doctorId);

        cita.setPaciente(paciente);
        cita.setDoctor(doctor);

        cita.setFechaYHoraDeFin(LocalDateTime.parse(request.getParameter("fechaYHoraDeFin")));
        cita.setFechaYHoraDeInicio(LocalDateTime.parse(request.getParameter("fechaYHoraDeInicio")));

        return cita;
    }
}