package com.espe.pry.idao;

import com.espe.pry.dao.IDAO;
import com.espe.pry.models.Usuario;
import com.espe.pry.utils.JPAutil;
import jakarta.persistence.EntityManager;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;

public class UsuarioDaoImpl implements IDAO<Usuario> {

    protected final EntityManager manager;

    public UsuarioDaoImpl() {
        manager = JPAutil.getEntityManager();
    }


    public void save(Usuario model) {
        manager.getTransaction().begin();
        manager.persist(model);
        manager.getTransaction().commit();
    }

    public void edit(Usuario model) {
        manager.getTransaction().begin();
        manager.merge(model);
        manager.getTransaction().commit();
    }

    public void delete(Usuario model) {
        manager.getTransaction().begin();
        manager.remove(model);
        manager.getTransaction().commit();
    }

    public Usuario find(Long id) {
        return manager.find(Usuario.class, id);
    }

    public List<Usuario> findAll() {
        return manager.createQuery("FROM Usuario", Usuario.class).getResultList();
    }

    @Override
    public Usuario parse(HttpServletRequest request) {
        Usuario usuario = new Usuario();

        usuario.setNombre(request.getParameter("nombre"));
        usuario.setApellido(request.getParameter("apellido"));
        usuario.setEmail(request.getParameter("email"));
        usuario.setPassword(request.getParameter("password"));

        return usuario;

    }
}